
from fastapi import FastAPI, Query
from typing import List
from pydantic import BaseModel
from datetime import date

app = FastAPI(title="입시 뉴스 포털 API")

class Article(BaseModel):
    id: int
    title: str
    content: str
    date: date
    source_url: str
    university_tag: List[str]
    topic_tag: List[str]

dummy_articles = [
    Article(
        id=1,
        title="서울대 수시 모집요강 발표",
        content="서울대학교가 2025학년도 수시 전형에 대한 요강을 발표했다.",
        date=date(2025, 5, 10),
        source_url="https://example.com/article1",
        university_tag=["서울대"],
        topic_tag=["수시"]
    ),
    Article(
        id=2,
        title="연세대 논술 일정 공개",
        content="연세대학교는 2025 논술고사 일정을 다음과 같이 공지했다.",
        date=date(2025, 5, 9),
        source_url="https://example.com/article2",
        university_tag=["연세대"],
        topic_tag=["논술"]
    ),
]

@app.get("/articles", response_model=List[Article])
def get_articles(
    university: str = Query(None),
    topic: str = Query(None)
):
    filtered = dummy_articles
    if university:
        filtered = [a for a in filtered if university in a.university_tag]
    if topic:
        filtered = [a for a in filtered if topic in a.topic_tag]
    return filtered
