
export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: 'sans-serif' }}>
      <h1>입시 뉴스 포털 사이트</h1>
      <p>지금은 초기 설정 중입니다. 곧 정식 오픈됩니다!</p>
    </div>
  );
}
